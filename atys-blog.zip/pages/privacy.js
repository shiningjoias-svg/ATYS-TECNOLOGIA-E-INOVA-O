
import Layout from '../components/Layout'
export default function Privacy() {
  return (
    <Layout>
      <h1 className="text-2xl font-semibold mb-4">Política de Privacidade</h1>
      <p className="text-atysGray-500">Esta é uma política de exemplo. Atualize com seus dados reais antes do lançamento.</p>
    </Layout>
  )
}
