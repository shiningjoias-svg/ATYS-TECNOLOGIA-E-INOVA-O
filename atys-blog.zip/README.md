
# ATYS Blog (Next.js + Tailwind + Netlify CMS)

**Como usar localmente**

1. Instale dependências:
```
npm install
```
2. Rode em modo de desenvolvimento:
```
npm run dev
```
Abra http://localhost:3000

**Netlify CMS**
- Para usar o painel Netlify CMS, hospede o site no Netlify (ou habilite o admin no seu provedor) e ajuste `admin/config.yml` com seu repositório.
- O arquivo admin/index.html está preparado para usar Netlify CMS via GitHub backend.

